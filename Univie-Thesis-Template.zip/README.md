LaTeX-Template für Abschlussarbeiten an der Fakultät für Mathematik der Universität Wien
========================================================================================

Um das Template ausführen zu können ist das *Logo der Universität Wien* erforderlich. Es kann 
[hier](http://public.univie.ac.at/fileadmin/user_upload/d_oeffentlichkeitsarbeit/Logos/2016-02/Uni_Logo_2016_SW.jpg)
bezogen werden. Bitte beachten Sie die Lizenzbedingungen dieser eingtragenen Wortbildmarke!

![titlepage_univie](https://cloud.githubusercontent.com/assets/11040405/24703254/c2f91434-1a02-11e7-984b-046740c37420.jpg)
